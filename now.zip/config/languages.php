<?php
return [
    'es' => ['Spanish', 'es_ES'],
    'en' => ['English', 'en_EN']
];
